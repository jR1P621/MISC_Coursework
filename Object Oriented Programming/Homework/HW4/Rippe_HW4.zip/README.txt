All programs are working as of 13 Apr 2020

Programs submitted as source code.

Problem #1 - Run as JavaFX
- Implemented Class member variables to give run() access to FX Objects
- Used boolean to end running thread

Problem #2 - Run as JavaFX
- Simulation can be paused and resumed.
- Drag feature can be used even if simulation is running.
- Some extra features added: Variable forest size, extra wind directions.