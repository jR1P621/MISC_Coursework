/*
   Represents a faculty member.
 */

/**
 *
 * @author Kenrick
 */
public class Faculty extends Person {

    public Faculty() {
        super();
    }

    public Faculty(String name, int ID) {
        super(name, ID);
    }

    public String toString() {
        return "Faculty " + super.toString();
    }
}
