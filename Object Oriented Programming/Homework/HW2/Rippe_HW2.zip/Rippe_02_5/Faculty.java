/*
   Represents a faculty member.
*/

/**
 *
 * @author Kenrick
 */
public class Faculty implements Affiliation {
	public Faculty() {
	}

	public String getAffiliation() {
		return "Faculty";
	}
}
