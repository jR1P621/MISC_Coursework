/*
  Represents a Student.
 */

/**
 *
 * @author Kenrick
 */
public class Student implements Affiliation {
	public Student() {
	}

	public String getAffiliation() {
		return "Student";
	}
}
