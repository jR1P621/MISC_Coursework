/*
   Affiliation interface creates Affiliation functionality for the Person class.
*/

/**
 *
 * @author Jon Rippe
 */
public interface Affiliation {
	public String getAffiliation();
}