public interface IterableCollection {
	public Iterator createIterator(); // Returns an Iterator
}