public class ChildrensMovie extends Movie {

	public ChildrensMovie() {
		super();
	}

	public ChildrensMovie(String title) {
		super(title);
	}
}
